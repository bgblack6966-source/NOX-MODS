// NOX MODS — EASY SETUP
// All normal settings live here. Keep this file private.
// IMPORTANT: never publish your BotFather token.

module.exports = {
  BOT_TOKEN: "PASTE_NEW_BOT_TOKEN_HERE",
  MAIN_ADMIN_IDS: ["PASTE_YOUR_TELEGRAM_ID_HERE"],

  BOT_NAME: "NOX MODS",
  BKASH_NUMBER: "01311237130",
  NAGAD_NUMBER: "N/A",
  SUPPORT_USERNAME: "@your_support_username",
  CHANNEL_USERNAME: "@your_channel_username",

  // Owner-only coupon. It is not shown in the user menu.
  SECRET_COUPON_CODE: "BLACKFREECOD100",

  // Put a direct URL here only if you want the payment page to show a hosted bKash logo.
  // The bot also includes the bKash logo file in assets/.
  BKASH_LOGO_URL: "https://upload.wikimedia.org/wikipedia/commons/c/cb/BKash-Bangla-Logo-01.png"
};
