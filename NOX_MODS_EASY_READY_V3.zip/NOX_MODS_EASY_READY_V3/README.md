# NOX MODS — EASY READY v3

Telegram FF panel store bot with button-based user/admin management.

## Included
- bKash payment number pre-set to `01311237130`
- Nagad marked `N/A`
- bKash logo shown on Add Balance screen using the configured logo URL
- User wallet, top-up request, transaction ID + sender number verification
- Admin approve/reject payment requests; approval automatically credits balance
- Categories such as ONLY HOLOGRAM / HOLOGRAM PLUS HEADSHOT
- Add panel with category, name, details, price, image URL and Telegram ZIP/document
- Panel delivery after successful purchase
- Purchase message includes channel and setup/support instruction
- Regular coupons: code, type, discount, usage limit and validity days
- Private owner coupon `BLACKFREECOD100`: unlimited, hidden from user menus, 100% free, bound to one panel selected by admin
- All users: balance, ban/unban, personal message, add balance, remove balance
- Add/remove admins; added admins get full admin permissions
- User Mode / Admin Mode buttons
- Broadcast popup to all non-banned users
- Change payment/support/channel/logo from admin settings
- Purchase security: no file is delivered unless a valid paid/free transaction completes; balance deduction is atomic to prevent rapid double-spend

## Setup
1. Open `config.js`.
2. Put your NEW BotFather token in `BOT_TOKEN`.
3. Put your Telegram numeric ID in `MAIN_ADMIN_IDS`.
4. Payment number is already `01311237130`; edit it later from Admin > Settings if needed.
5. Run:
   - `npm install`
   - `npm start`

The database is stored in `data/nox_mods.db`.

## Admin
Send `/admin` from an authorized account. Everything is button based.

## Important
Never publish `config.js` because it contains your bot token. If a token has ever been shared publicly, revoke it in BotFather and use a fresh token.
