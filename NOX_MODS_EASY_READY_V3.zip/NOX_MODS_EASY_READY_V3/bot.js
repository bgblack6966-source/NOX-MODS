const { Telegraf, Markup, session } = require('telegraf');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const CONFIG = require('./config');

if (!CONFIG.BOT_TOKEN || CONFIG.BOT_TOKEN.startsWith('PASTE_')) {
  throw new Error('Open config.js and paste a NEW BotFather token.');
}
if (!Array.isArray(CONFIG.MAIN_ADMIN_IDS) || !CONFIG.MAIN_ADMIN_IDS.length || CONFIG.MAIN_ADMIN_IDS.some(x => String(x).startsWith('PASTE_'))) {
  throw new Error('Open config.js and put your Telegram ID in MAIN_ADMIN_IDS.');
}

const DATA_DIR = path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, 'nox_mods.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, name TEXT, username TEXT, balance REAL DEFAULT 0,
  banned INTEGER DEFAULT 0, created_at INTEGER, updated_at INTEGER
);
CREATE TABLE IF NOT EXISTS admins (
  user_id TEXT PRIMARY KEY, role TEXT DEFAULT 'admin', added_by TEXT, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, active INTEGER DEFAULT 1, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT, category_id TEXT, name TEXT NOT NULL,
  details TEXT, price REAL NOT NULL, image_url TEXT, file_id TEXT, active INTEGER DEFAULT 1, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS topups (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, amount REAL NOT NULL,
  tx_id TEXT, sender_number TEXT, status TEXT DEFAULT 'pending', created_at INTEGER, reviewed_at INTEGER, reviewer_id TEXT
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, product_id INTEGER,
  product_name TEXT, original_price REAL, paid_price REAL, coupon_id INTEGER, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS coupons (
  id INTEGER PRIMARY KEY AUTOINCREMENT, code_hash TEXT UNIQUE, code_label TEXT,
  type TEXT, value REAL DEFAULT 0, max_uses INTEGER DEFAULT -1, uses INTEGER DEFAULT 0,
  expires_at INTEGER, min_order REAL DEFAULT 0, product_id INTEGER, category_id TEXT,
  active INTEGER DEFAULT 1, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS coupon_uses (
  id INTEGER PRIMARY KEY AUTOINCREMENT, coupon_id INTEGER, user_id TEXT, order_id INTEGER, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
`);

const q = {
  setSetting: db.prepare(`INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value`),
  getSetting: db.prepare('SELECT value FROM settings WHERE key=?'),
  user: db.prepare('SELECT * FROM users WHERE id=?'),
  users: db.prepare('SELECT * FROM users ORDER BY id DESC LIMIT 100'),
  category: db.prepare('SELECT * FROM categories WHERE id=?'),
  categories: db.prepare('SELECT * FROM categories WHERE active=1 ORDER BY created_at DESC'),
  product: db.prepare('SELECT * FROM products WHERE id=?'),
  activeProduct: db.prepare('SELECT * FROM products WHERE id=? AND active=1'),
  products: db.prepare('SELECT * FROM products ORDER BY id DESC LIMIT 100'),
  topup: db.prepare('SELECT * FROM topups WHERE id=?'),
  pendingTopups: db.prepare(`SELECT * FROM topups WHERE status='pending' ORDER BY id DESC LIMIT 50`),
  couponByHash: db.prepare('SELECT * FROM coupons WHERE code_hash=?'),
  activeCoupons: db.prepare('SELECT * FROM coupons ORDER BY id DESC LIMIT 100')
};

const setSetting = (k, v) => q.setSetting.run(k, String(v));
const getSetting = k => q.getSetting.get(k)?.value || '';
setSetting('payment_number', getSetting('payment_number') || CONFIG.BKASH_NUMBER);
setSetting('nagad_number', getSetting('nagad_number') || CONFIG.NAGAD_NUMBER);
setSetting('support', getSetting('support') || CONFIG.SUPPORT_USERNAME);
setSetting('channel', getSetting('channel') || CONFIG.CHANNEL_USERNAME);
setSetting('bkash_logo', getSetting('bkash_logo') || CONFIG.BKASH_LOGO_URL);

const mainAdminIds = CONFIG.MAIN_ADMIN_IDS.map(String);
for (const id of mainAdminIds) {
  db.prepare(`INSERT INTO admins(user_id,role,added_by,created_at) VALUES(?,?,?,?)
    ON CONFLICT(user_id) DO UPDATE SET role='main'`).run(id, 'main', id, Date.now());
}

const bot = new Telegraf(CONFIG.BOT_TOKEN);
bot.use(session());
const now = () => Date.now();
const money = n => `৳${Number(n || 0).toLocaleString('en-BD', { maximumFractionDigits: 2 })}`;
const hashCode = code => crypto.createHash('sha256').update(String(code).trim().toUpperCase()).digest('hex');
const esc = s => String(s ?? '').replace(/[<>&]/g, m => ({'<':'&lt;','>':'&gt;','&':'&amp;'}[m]));
const cleanUsername = u => String(u || '').replace(/^@/, '');
const userUrl = u => `https://t.me/${cleanUsername(u)}`;
const isMainAdmin = id => mainAdminIds.includes(String(id));
const isAdmin = id => !!db.prepare('SELECT user_id FROM admins WHERE user_id=?').get(String(id));
const isBanned = id => !!db.prepare('SELECT banned FROM users WHERE id=?').get(String(id))?.banned;
const balance = id => Number(db.prepare('SELECT balance FROM users WHERE id=?').get(String(id))?.balance || 0);

// Secret owner coupon: always private, unlimited, but only works for the one panel selected by admin.
const SECRET = hashCode(CONFIG.SECRET_COUPON_CODE);
let secretRow = q.couponByHash.get(SECRET);
if (!secretRow) {
  db.prepare(`INSERT INTO coupons(code_hash,code_label,type,value,max_uses,uses,expires_at,min_order,product_id,category_id,active,created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(SECRET, 'OWNER PRIVATE FREE', 'FREE', 0, -1, 0, null, 0, null, null, 1, now());
}

function ensureUser(ctx) {
  const u = ctx.from;
  db.prepare(`INSERT INTO users(id,name,username,created_at,updated_at) VALUES(?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET name=excluded.name, username=excluded.username, updated_at=excluded.updated_at`)
    .run(String(u.id), u.first_name || 'User', u.username || '', now(), now());
}

function mainKeyboard(id) {
  const rows = [
    [Markup.button.callback('🛒 Buy Panel', 'buy'), Markup.button.callback('💰 Balance', 'balance')],
    [Markup.button.callback('📜 Order History', 'history'), Markup.button.callback('🧾 Top-up History', 'topuphist')],
    [Markup.button.callback('🆘 Support', 'support')]
  ];
  if (isAdmin(id)) rows.push([Markup.button.callback('🛠️ Admin Panel', 'a_home')]);
  return Markup.inlineKeyboard(rows);
}

function adminKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('📁 Create Category', 'a_cat'), Markup.button.callback('🎮 Add New Panel', 'a_panel')],
    [Markup.button.callback('🎟️ Coupons', 'a_coupons'), Markup.button.callback('🔐 Secret FREE', 'a_secret')],
    [Markup.button.callback('👥 All Users', 'a_users'), Markup.button.callback('👮 Admins', 'a_admins')],
    [Markup.button.callback('💳 Payment Requests', 'a_topups'), Markup.button.callback('📢 New Popup', 'a_popup')],
    [Markup.button.callback('📦 Manage Panels', 'a_products'), Markup.button.callback('🗂️ Categories', 'a_categories')],
    [Markup.button.callback('⚙️ Settings', 'a_settings'), Markup.button.callback('📊 Statistics', 'a_stats')],
    [Markup.button.callback('👤 User Mode', 'home')]
  ]);
}

async function editOrReply(ctx, text, keyboard) {
  if (ctx.callbackQuery) {
    return ctx.editMessageText(text, { parse_mode: 'HTML', ...keyboard }).catch(() => ctx.reply(text, { parse_mode: 'HTML', ...keyboard }));
  }
  return ctx.reply(text, { parse_mode: 'HTML', ...keyboard });
}

async function home(ctx, text) {
  ensureUser(ctx);
  if (isBanned(ctx.from.id)) return ctx.reply('🚫 Your account is banned. Please contact admin.');
  const msg = text || `🔥 <b>${esc(CONFIG.BOT_NAME)}</b>\n\nPremium FF panel store.\n\n💰 Balance: <b>${money(balance(ctx.from.id))}</b>\n\nChoose an option:`;
  return editOrReply(ctx, msg, mainKeyboard(ctx.from.id));
}

function backHome() { return Markup.inlineKeyboard([[Markup.button.callback('⬅️ Back', 'home')]]); }

bot.start(ctx => home(ctx, `🔥 <b>${esc(CONFIG.BOT_NAME)}</b>\n\nWelcome to the premium FF panel store.\n\n💰 Balance: <b>${money(balance(ctx.from.id))}</b>\n\nSelect an option below:`));
bot.command('admin', ctx => isAdmin(ctx.from.id) ? editOrReply(ctx, `🛠️ <b>${esc(CONFIG.BOT_NAME)} Admin Panel</b>\n\nUse the buttons below to manage everything.`, adminKeyboard()) : ctx.reply('⛔ Admin access only.'));
bot.action('home', ctx => { ctx.answerCbQuery().catch(()=>{}); ctx.session = {}; return home(ctx); });

bot.action('balance', async ctx => {
  await ctx.answerCbQuery(); ensureUser(ctx);
  await ctx.editMessageText(`💰 <b>Your Balance</b>\n\nAvailable: <b>${money(balance(ctx.from.id))}</b>`, { parse_mode: 'HTML', ...Markup.inlineKeyboard([[Markup.button.callback('➕ Add Balance', 'topup')], [Markup.button.callback('⬅️ Back', 'home')]]) });
});

bot.action('topup', async ctx => {
  await ctx.answerCbQuery(); ensureUser(ctx); ctx.session.step = 'topup_amount';
  const caption = `➕ <b>Add Balance</b>\n\n💗 <b>bKash Send Money</b>\n📱 Number: <code>${esc(getSetting('payment_number'))}</code>\n\nSend Money only — exact amount.\nNagad: <b>${esc(getSetting('nagad_number'))}</b>\n\nNow send the amount you want to add, for example: <code>500</code>`;
  try { await ctx.replyWithPhoto(getSetting('bkash_logo'), { caption, parse_mode: 'HTML', ...backHome() }); }
  catch (_) { await ctx.editMessageText(caption, { parse_mode: 'HTML', ...backHome() }); }
});

bot.action('support', async ctx => {
  await ctx.answerCbQuery();
  const s = getSetting('support');
  const buttons = [];
  if (cleanUsername(s)) buttons.push([Markup.button.url('💬 Message Admin', userUrl(s))]);
  const ch = getSetting('channel');
  if (cleanUsername(ch)) buttons.push([Markup.button.url('📢 Join Channel', `https://t.me/${cleanUsername(ch)}`)]);
  buttons.push([Markup.button.callback('⬅️ Back', 'home')]);
  await ctx.editMessageText(`🆘 <b>Support</b>\n\nAdmin: ${esc(s || 'Not set')}\n\nSetup না হলে বা payment/order সমস্যায় admin-কে message দিন।`, { parse_mode: 'HTML', ...Markup.inlineKeyboard(buttons) });
});

bot.action('history', async ctx => {
  await ctx.answerCbQuery();
  const rows = db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 20').all(String(ctx.from.id));
  const text = rows.length ? rows.map((r,i) => `${i+1}. <b>${esc(r.product_name)}</b> — ${money(r.paid_price)}\n   ${new Date(r.created_at).toLocaleString()}`).join('\n\n') : 'No purchases yet.';
  await ctx.editMessageText(`📜 <b>Order History</b>\n\n${text}`, { parse_mode: 'HTML', ...backHome() });
});

bot.action('topuphist', async ctx => {
  await ctx.answerCbQuery();
  const rows = db.prepare('SELECT * FROM topups WHERE user_id=? ORDER BY id DESC LIMIT 20').all(String(ctx.from.id));
  const text = rows.length ? rows.map(r => `${money(r.amount)} — <b>${r.status.toUpperCase()}</b>\nTX: <code>${esc(r.tx_id)}</code>\nSender: <code>${esc(r.sender_number)}</code>`).join('\n\n') : 'No top-ups yet.';
  await ctx.editMessageText(`🧾 <b>Top-up History</b>\n\n${text}`, { parse_mode: 'HTML', ...backHome() });
});

bot.action('buy', async ctx => {
  await ctx.answerCbQuery();
  const cats = q.categories.all();
  if (!cats.length) return ctx.editMessageText('🛒 No panel categories are available yet.', { ...backHome() });
  await ctx.editMessageText('🛒 <b>Buy Panel</b>\n\nChoose a category:', { parse_mode: 'HTML', ...Markup.inlineKeyboard(cats.map(c => [Markup.button.callback(`📁 ${c.name}`, `cat:${c.id}`)]).concat([[Markup.button.callback('⬅️ Back', 'home')]])) });
});

bot.action(/^cat:(.+)$/, async ctx => {
  await ctx.answerCbQuery();
  const cid = ctx.match[1]; const c = q.category.get(cid);
  const ps = db.prepare('SELECT * FROM products WHERE category_id=? AND active=1 ORDER BY id DESC').all(cid);
  if (!ps.length) return ctx.editMessageText(`📁 <b>${esc(c?.name || cid)}</b>\n\nNo panels here yet.`, { parse_mode: 'HTML', ...Markup.inlineKeyboard([[Markup.button.callback('⬅️ Categories', 'buy')]]) });
  await ctx.editMessageText(`📁 <b>${esc(c?.name || cid)}</b>\n\nChoose a panel:`, { parse_mode: 'HTML', ...Markup.inlineKeyboard(ps.map(p => [Markup.button.callback(`🎮 ${p.name} — ${money(p.price)}`, `product:${p.id}`)]).concat([[Markup.button.callback('⬅️ Categories', 'buy')]])) });
});

async function showProduct(ctx, p) {
  ctx.session.selectedProduct = p.id;
  const text = `🎮 <b>${esc(p.name)}</b>\n\n${esc(p.details || 'No details')}\n\n💵 Price: <b>${money(p.price)}</b>\n💰 Your balance: <b>${money(balance(ctx.from.id))}</b>\n\n🔐 After purchase the panel file will be delivered here. Do not share the panel. Setup না হলে admin-কে message দিন.`;
  const kb = Markup.inlineKeyboard([[Markup.button.callback('🛒 Buy Now', `buyconfirm:${p.id}`)], [Markup.button.callback('⬅️ Back', `cat:${p.category_id}`)]]);
  if (p.image_url) {
    try { return await ctx.replyWithPhoto(p.image_url, { caption: text, parse_mode: 'HTML', ...kb }); } catch (_) {}
  }
  return ctx.editMessageText(text, { parse_mode: 'HTML', ...kb });
}

bot.action(/^product:(\d+)$/, async ctx => {
  await ctx.answerCbQuery(); const p = q.activeProduct.get(Number(ctx.match[1])); if (!p) return;
  await showProduct(ctx, p);
});

bot.action(/^buyconfirm:(\d+)$/, async ctx => {
  await ctx.answerCbQuery(); const p = q.activeProduct.get(Number(ctx.match[1])); if (!p) return;
  ctx.session.selectedProduct = p.id; ctx.session.step = 'coupon';
  await ctx.editMessageText(`⚠️ <b>Confirm Purchase</b>\n\nPanel: <b>${esc(p.name)}</b>\nPrice: <b>${money(p.price)}</b>\n\nHave a coupon? Send the coupon code.\nOr send <code>NO</code> to continue without coupon.`, { parse_mode: 'HTML', ...Markup.inlineKeyboard([[Markup.button.callback('❌ Cancel', `product:${p.id}`)]]) });
});

function findCoupon(code) { return q.couponByHash.get(hashCode(code)); }
function validCoupon(c, userId, p) {
  if (!c || !c.active) return { ok:false, reason:'Invalid or inactive coupon.' };
  if (c.expires_at && c.expires_at < now()) return { ok:false, reason:'Coupon expired.' };
  if (c.max_uses >= 0 && c.uses >= c.max_uses) return { ok:false, reason:'Coupon usage limit reached.' };
  if (c.product_id && Number(c.product_id) !== Number(p.id)) return { ok:false, reason:'This coupon is not valid for this panel.' };
  if (c.category_id && c.category_id !== p.category_id) return { ok:false, reason:'This coupon is not valid for this category.' };
  const used = db.prepare('SELECT COUNT(*) n FROM coupon_uses WHERE coupon_id=? AND user_id=?').get(c.id, String(userId)).n;
  if (c.per_user_limit && used >= c.per_user_limit) return { ok:false, reason:'You already used this coupon.' };
  if (p.price < Number(c.min_order || 0)) return { ok:false, reason:`Minimum order is ${money(c.min_order)}.` };
  return { ok:true };
}
function discounted(p, c) {
  if (!c) return { final:Number(p.price), discount:0 };
  if (c.type === 'FREE') return { final:0, discount:Number(p.price) };
  if (c.type === 'PERCENT') { const d = Math.min(Number(p.price), Number(p.price) * Number(c.value) / 100); return { final:Number(p.price)-d, discount:d }; }
  const d = Math.min(Number(p.price), Number(c.value)); return { final:Number(p.price)-d, discount:d };
}

async function completePurchase(ctx, p, coupon) {
  const price = Number(p.price); const calc = discounted(p, coupon); const final = Math.max(0, Number(calc.final.toFixed(2)));
  if (final > 0 && balance(ctx.from.id) < final) {
    return ctx.reply(`❌ <b>Insufficient Balance</b>\n\nNeed: <b>${money(final)}</b>\nYour balance: <b>${money(balance(ctx.from.id))}</b>\n\nPlease add balance first.`, { parse_mode:'HTML', ...Markup.inlineKeyboard([[Markup.button.callback('➕ Add Balance','topup')],[Markup.button.callback('⬅️ Home','home')]]) });
  }
  if (!p.file_id) return ctx.reply('❌ This panel has no ZIP/file attached yet. Setup না হলে admin-কে message দিন.');

  let orderId;
  const transaction = db.transaction(() => {
    // Re-check balance inside the transaction to prevent double-spend from rapid taps.
    if (final > 0) {
      const u = db.prepare('SELECT balance,banned FROM users WHERE id=?').get(String(ctx.from.id));
      if (!u || u.banned || Number(u.balance) < final) throw new Error('BALANCE');
      db.prepare('UPDATE users SET balance=balance-?,updated_at=? WHERE id=?').run(final, now(), String(ctx.from.id));
    }
    const order = db.prepare(`INSERT INTO orders(user_id,product_id,product_name,original_price,paid_price,coupon_id,created_at)
      VALUES(?,?,?,?,?,?,?)`).run(String(ctx.from.id), p.id, p.name, price, final, coupon?.id || null, now());
    orderId = order.lastInsertRowid;
    if (coupon) db.prepare('UPDATE coupons SET uses=uses+1 WHERE id=?').run(coupon.id);
    if (coupon) db.prepare('INSERT INTO coupon_uses(coupon_id,user_id,order_id,created_at) VALUES(?,?,?,?)').run(coupon.id, String(ctx.from.id), orderId, now());
  });
  try { transaction(); } catch (e) { return ctx.reply(e.message === 'BALANCE' ? '❌ Purchase failed: balance is not enough.' : '❌ Purchase failed. Please try again.'); }

  const ch = getSetting('channel');
  const setup = `\n\n🛠️ <b>Setup problem?</b> Admin-কে message দিন: ${esc(getSetting('support'))}`;
  const channel = cleanUsername(ch) ? `\n📢 Channel: @${cleanUsername(ch)}` : '';
  const caption = `✅ <b>Purchase Successful</b>\n\n🎮 Panel: <b>${esc(p.name)}</b>\n💳 Paid: <b>${money(final)}</b>\n${calc.discount > 0 ? `🎟️ Discount: <b>${money(calc.discount)}</b>\n` : ''}🧾 Order: <code>#${orderId}</code>${channel}${setup}\n\n⚠️ Do not share this panel file.`;
  try { await ctx.replyWithDocument(p.file_id, { caption, parse_mode:'HTML' }); }
  catch (_) { await ctx.reply(caption, { parse_mode:'HTML' }); }
}

bot.on('text', async ctx => {
  ensureUser(ctx);
  const s = ctx.session || (ctx.session = {}); const t = ctx.message.text.trim();
  if (isBanned(ctx.from.id) && !isAdmin(ctx.from.id)) return ctx.reply('🚫 Your account is banned. Please contact admin.');

  // User top-up flow
  if (s.step === 'topup_amount') {
    const amount = Number(t);
    if (!Number.isFinite(amount) || amount <= 0) return ctx.reply('❌ Send a valid amount, e.g. 500.');
    s.topupAmount = amount; s.step = 'topup_tx';
    return ctx.reply(`💗 Send Money exactly <b>${money(amount)}</b> to bKash <code>${esc(getSetting('payment_number'))}</code>.\n\nNow send the <b>Transaction ID</b>.`, { parse_mode:'HTML' });
  }
  if (s.step === 'topup_tx') {
    s.tx = t; s.step = 'topup_sender';
    return ctx.reply('📱 Now send the bKash sender number used for the payment.');
  }
  if (s.step === 'topup_sender') {
    const amount = Number(s.topupAmount); const tx = s.tx; const sender = t;
    const r = db.prepare(`INSERT INTO topups(user_id,amount,tx_id,sender_number,status,created_at) VALUES(?,?,?,?,?,?)`).run(String(ctx.from.id), amount, tx, sender, 'pending', now());
    s.step = null; s.topupAmount = null; s.tx = null;
    for (const a of db.prepare('SELECT user_id FROM admins').all()) {
      bot.telegram.sendMessage(a.user_id, `💳 <b>New Payment Request #${r.lastInsertRowid}</b>\n\nUser: <code>${ctx.from.id}</code>\nAmount: <b>${money(amount)}</b>\nTX ID: <code>${esc(tx)}</code>\nSender: <code>${esc(sender)}</code>`, { parse_mode:'HTML', ...Markup.inlineKeyboard([[Markup.button.callback('🔎 Check Request', `a_t:${r.lastInsertRowid}`)]]) }).catch(()=>{});
    }
    return ctx.reply('✅ Payment request received. Admin will check the amount, transaction ID and sender number. If approved, your balance will be added automatically.', { ...mainKeyboard(ctx.from.id) });
  }

  // User coupon flow
  if (s.step === 'coupon') {
    const p = q.activeProduct.get(Number(s.selectedProduct));
    if (!p) { s.step=null; return ctx.reply('Panel not found.'); }
    let coupon = null;
    if (t.toUpperCase() !== 'NO') {
      coupon = findCoupon(t);
      const check = validCoupon(coupon, ctx.from.id, p);
      if (!check.ok) return ctx.reply(`❌ ${check.reason}\n\nSend another coupon or <code>NO</code>.`, { parse_mode:'HTML' });
    }
    s.step = null;
    const calc = discounted(p, coupon);
    return ctx.reply(`🧾 <b>Final Confirmation</b>\n\nPanel: <b>${esc(p.name)}</b>\nOriginal: ${money(p.price)}\nDiscount: ${money(calc.discount)}\n<b>Pay: ${money(calc.final)}</b>\n\nConfirm?`, { parse_mode:'HTML', ...Markup.inlineKeyboard([[Markup.button.callback('✅ Confirm Buy', `finalbuy:${p.id}:${coupon?.id || 0}`), Markup.button.callback('❌ Cancel', `product:${p.id}`)]]) });
  }

  // Admin flows
  if (!isAdmin(ctx.from.id) || !s.adminStep) return;
  const step = s.adminStep;

  if (step === 'cat_create') {
    const name = t.trim(); if (name.length < 2) return ctx.reply('Category name is too short.');
    const id = 'cat_' + crypto.randomBytes(4).toString('hex');
    db.prepare('INSERT INTO categories(id,name,active,created_at) VALUES(?,?,1,?)').run(id, name, now()); s.adminStep=null;
    return ctx.reply(`✅ Category created.\n\n📁 ${esc(name)}`);
  }
  if (step === 'panel_name') { s.panelName=t; s.adminStep='panel_details'; return ctx.reply('📝 Send panel details/description:'); }
  if (step === 'panel_details') { s.panelDetails=t; s.adminStep='panel_price'; return ctx.reply('💵 Send panel price, e.g. 500:'); }
  if (step === 'panel_price') { const n=Number(t); if(!Number.isFinite(n)||n<0)return ctx.reply('Send a valid price.'); s.panelPrice=n; s.adminStep='panel_image'; return ctx.reply('🖼️ Send panel image URL, or send <code>SKIP</code>.', {parse_mode:'HTML'}); }
  if (step === 'panel_image') { s.panelImage = /^skip$/i.test(t) ? '' : t; s.adminStep='panel_file'; return ctx.reply('📦 Now send the panel ZIP/file as a Telegram document.'); }
  if (step === 'payment') { setSetting('payment_number', t); s.adminStep=null; return ctx.reply('✅ bKash number updated.'); }
  if (step === 'support') { setSetting('support', t); s.adminStep=null; return ctx.reply('✅ Support username updated.'); }
  if (step === 'channel') { setSetting('channel', t); s.adminStep=null; return ctx.reply('✅ Channel updated.'); }
  if (step === 'bkash_logo') { setSetting('bkash_logo', t); s.adminStep=null; return ctx.reply('✅ bKash logo URL updated.'); }
  if (step === 'user_search') { return adminUserSearch(ctx, t); }
  if (step === 'user_add') { return adminAdjustBalance(ctx, t, 1); }
  if (step === 'user_minus') { return adminAdjustBalance(ctx, t, -1); }
  if (step === 'user_message') { const uid=s.targetUser; s.adminStep=null; try { await bot.telegram.sendMessage(uid, `📩 <b>Message from Admin</b>\n\n${esc(t)}`, {parse_mode:'HTML'}); return ctx.reply('✅ Message sent.'); } catch(_) { return ctx.reply('❌ Could not message this user.'); } }
  if (step === 'broadcast') { s.adminStep=null; const users=db.prepare('SELECT id FROM users WHERE banned=0').all(); let ok=0; for(const u of users){try{await bot.telegram.sendMessage(u.id, `📢 <b>${esc(CONFIG.BOT_NAME)} Notification</b>\n\n${esc(t)}`,{parse_mode:'HTML'});ok++;}catch(_){}} return ctx.reply(`✅ Popup sent to ${ok}/${users.length} users.`); }
  if (step === 'new_admin') { const uid=t.replace(/\D/g,''); if(!uid)return ctx.reply('Send numeric Telegram ID.'); db.prepare('INSERT OR REPLACE INTO admins(user_id,role,added_by,created_at) VALUES(?,?,?,?)').run(uid,'admin',String(ctx.from.id),now()); return (s.adminStep=null,ctx.reply(`✅ ${uid} is now an admin with full permissions.`)); }
  if (step === 'coupon_code') { s.couponCode=t; s.adminStep='coupon_type'; return ctx.reply('Choose type: FIXED / PERCENT / FREE'); }
  if (step === 'coupon_type') { const type=t.toUpperCase(); if(!['FIXED','PERCENT','FREE'].includes(type))return ctx.reply('Type must be FIXED, PERCENT or FREE.'); s.couponType=type; s.adminStep='coupon_value'; return ctx.reply(type==='FREE'?'Value will be 0. Send any text to continue, e.g. 0.':'Send discount value. For PERCENT use 20 for 20%.'); }
  if (step === 'coupon_value') { const v=Number(t); if(!Number.isFinite(v)||v<0)return ctx.reply('Send a valid value.'); if(s.couponType==='PERCENT'&&v>100)return ctx.reply('Percent cannot exceed 100.'); s.couponValue=s.couponType==='FREE'?0:v; s.adminStep='coupon_uses'; return ctx.reply('How many total users can use it? Send -1 for unlimited.'); }
  if (step === 'coupon_uses') { const v=Number(t); if(!Number.isInteger(v)||v===0||v<-1)return ctx.reply('Send -1 or a positive whole number.'); s.couponUses=v; s.adminStep='coupon_days'; return ctx.reply('How many days can it be used? Send -1 for unlimited.'); }
  if (step === 'coupon_days') { const d=Number(t); if(!Number.isInteger(d)||d===0||d<-1)return ctx.reply('Send -1 or a positive whole number.'); const exp=d<0?null:now()+d*86400000; const code=s.couponCode.toUpperCase(); if(findCoupon(code)) return ctx.reply('❌ That coupon already exists. Start again with a new code.'); db.prepare(`INSERT INTO coupons(code_hash,code_label,type,value,max_uses,uses,expires_at,min_order,product_id,category_id,active,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(hashCode(code),code,s.couponType,s.couponValue,s.couponUses,0,exp,0,null,null,1,now()); s.adminStep=null; return ctx.reply(`✅ Coupon created.\n\nCode: <code>${esc(code)}</code>\nType: ${s.couponType}\nDiscount: ${s.couponType==='PERCENT'?s.couponValue+'%':money(s.couponValue)}\nUses: ${s.couponUses<0?'Unlimited':s.couponUses}\nValidity: ${d<0?'Unlimited':d+' days'}`,{parse_mode:'HTML'}); }
  if (step === 'panel_file') return ctx.reply('Please send the panel ZIP/file as a Telegram document.');
});

bot.on('document', async ctx => {
  ensureUser(ctx); const s=ctx.session||{};
  if (!isAdmin(ctx.from.id) || s.adminStep !== 'panel_file') return;
  if (!s.panelCategory) return ctx.reply('Category not selected.');
  const fileId=ctx.message.document.file_id;
  const r=db.prepare(`INSERT INTO products(category_id,name,details,price,image_url,file_id,active,created_at) VALUES(?,?,?,?,?,?,1,?)`).run(s.panelCategory,s.panelName,s.panelDetails||'',Number(s.panelPrice),s.panelImage||'',fileId,now());
  ctx.session={}; return ctx.reply(`✅ <b>Panel created</b>\n\nID: #${r.lastInsertRowid}\nName: ${esc(s.panelName)}\nPrice: ${money(s.panelPrice)}\nZIP/File: saved`,{parse_mode:'HTML'});
});

bot.action(/^finalbuy:(\d+):(\d+)$/, async ctx => {
  await ctx.answerCbQuery(); const p=q.activeProduct.get(Number(ctx.match[1])); if(!p)return;
  const cid=Number(ctx.match[2]); const c=cid?db.prepare('SELECT * FROM coupons WHERE id=?').get(cid):null;
  if(c){const check=validCoupon(c,ctx.from.id,p);if(!check.ok)return ctx.reply(`❌ ${check.reason}`);}
  return completePurchase(ctx,p,c);
});

// ---------------- ADMIN ----------------
async function adminHome(ctx) { if(!isAdmin(ctx.from.id))return; ctx.session={}; await ctx.answerCbQuery().catch(()=>{}); return editOrReply(ctx, `🛠️ <b>${esc(CONFIG.BOT_NAME)} Admin Panel</b>\n\nAll management options are available below.\n\n🔐 Main admins and added admins have full permissions.`, adminKeyboard()); }
bot.action('a_home', adminHome);
bot.action('a_cat', async ctx=>{if(!isAdmin(ctx.from.id))return;await ctx.answerCbQuery();const cats=q.categories.all();await ctx.editMessageText(`📁 <b>Create New Category</b>\n\nCurrent: ${cats.length}\n\nTap Create and send a name such as ONLY HOLOGRAM or HOLOGRAM PLUS HEADSHOT.`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('➕ Create Category','a_cat_do')],[Markup.button.callback('🗑️ Delete Category','a_cat_del')],[Markup.button.callback('⬅️ Admin','a_home')]])});});
bot.action('a_cat_do',async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session.adminStep='cat_create';await ctx.answerCbQuery();await ctx.reply('📁 Send the new category name:');});
bot.action('a_cat_del',async ctx=>{if(!isAdmin(ctx.from.id))return;const cats=q.categories.all();await ctx.answerCbQuery();await ctx.editMessageText('Select a category to deactivate:',{...Markup.inlineKeyboard(cats.map(c=>[Markup.button.callback(`🗑️ ${c.name}`,`a_cat_delete:${c.id}`)]).concat([[Markup.button.callback('⬅️ Admin','a_home')]]))});});
bot.action(/^a_cat_delete:(.+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;db.prepare('UPDATE categories SET active=0 WHERE id=?').run(ctx.match[1]);await ctx.answerCbQuery('Deleted');await adminHome(ctx);});

bot.action('a_panel',async ctx=>{if(!isAdmin(ctx.from.id))return;const cats=q.categories.all();await ctx.answerCbQuery();if(!cats.length)return ctx.reply('Create a category first.');await ctx.editMessageText('🎮 <b>Add New Panel</b>\n\nFirst select its category:',{parse_mode:'HTML',...Markup.inlineKeyboard(cats.map(c=>[Markup.button.callback(`📁 ${c.name}`,`a_panel_cat:${c.id}`)]).concat([[Markup.button.callback('⬅️ Admin','a_home')]]))});});
bot.action(/^a_panel_cat:(.+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session={adminStep:'panel_name',panelCategory:ctx.match[1]};await ctx.answerCbQuery();await ctx.reply('🎮 Send panel name, e.g. GREEN HOLOGRAM:');});

bot.action('a_products',async ctx=>{if(!isAdmin(ctx.from.id))return;const ps=q.products.all();await ctx.answerCbQuery();await ctx.editMessageText(`📦 <b>Manage Panels</b>\n\nSelect a panel:`,{parse_mode:'HTML',...Markup.inlineKeyboard(ps.map(p=>[Markup.button.callback(`${p.active?'🟢':'🔴'} ${p.name} — ${money(p.price)}`,`a_prod:${p.id}`)]).concat([[Markup.button.callback('⬅️ Admin','a_home')]]))});});
bot.action(/^a_prod:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;const p=q.product.get(Number(ctx.match[1]));if(!p)return;await ctx.answerCbQuery();await ctx.editMessageText(`🎮 <b>${esc(p.name)}</b>\n\nCategory: ${esc(q.category.get(p.category_id)?.name||p.category_id)}\nPrice: ${money(p.price)}\nFile: ${p.file_id?'Attached':'MISSING'}\nImage: ${p.image_url?'Set':'None'}\nStatus: ${p.active?'Active':'Disabled'}`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback(p.active?'🔴 Disable':'🟢 Enable',`a_prod_toggle:${p.id}`),Markup.button.callback('🗑️ Delete','a_prod_delete:'+p.id)],[Markup.button.callback('⬅️ Panels','a_products')]])});});
bot.action(/^a_prod_toggle:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;const p=q.product.get(Number(ctx.match[1]));db.prepare('UPDATE products SET active=? WHERE id=?').run(p.active?0:1,p.id);await ctx.answerCbQuery('Updated');await adminHome(ctx);});
bot.action(/^a_prod_delete:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;db.prepare('UPDATE products SET active=0 WHERE id=?').run(Number(ctx.match[1]));await ctx.answerCbQuery('Deleted');await adminHome(ctx);});

bot.action('a_categories',async ctx=>{if(!isAdmin(ctx.from.id))return;const cats=q.categories.all();await ctx.answerCbQuery();await ctx.editMessageText(`🗂️ <b>Categories</b>\n\n${cats.length?cats.map(c=>`• ${esc(c.name)} — <code>${esc(c.id)}</code>`).join('\n'):'None'}`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('➕ Create Category','a_cat_do')],[Markup.button.callback('⬅️ Admin','a_home')]])});});

bot.action('a_topups',async ctx=>{if(!isAdmin(ctx.from.id))return;const rows=q.pendingTopups.all();await ctx.answerCbQuery();if(!rows.length)return ctx.editMessageText('💳 No pending payment requests.',{...Markup.inlineKeyboard([[Markup.button.callback('⬅️ Admin','a_home')]])});await ctx.editMessageText('💳 <b>Payment Requests</b>\n\nSelect a request to check amount, TX ID and sender number:',{parse_mode:'HTML',...Markup.inlineKeyboard(rows.map(x=>[Markup.button.callback(`#${x.id} • ${money(x.amount)}`,`a_t:${x.id}`)]).concat([[Markup.button.callback('⬅️ Admin','a_home')]]))});});
bot.action(/^a_t:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;const x=q.topup.get(Number(ctx.match[1]));if(!x)return;await ctx.answerCbQuery();await ctx.editMessageText(`💳 <b>Payment Request #${x.id}</b>\n\nUser: <code>${x.user_id}</code>\nAmount: <b>${money(x.amount)}</b>\nTX ID: <code>${esc(x.tx_id)}</code>\nSender: <code>${esc(x.sender_number)}</code>\nStatus: <b>${x.status}</b>`,{parse_mode:'HTML',...Markup.inlineKeyboard(x.status==='pending'?[[Markup.button.callback('✅ Confirm + Add Balance',`approve:${x.id}`),Markup.button.callback('❌ Reject',`reject:${x.id}`)],[Markup.button.callback('⬅️ Requests','a_topups')]]:[[Markup.button.callback('⬅️ Requests','a_topups')]])});});
bot.action(/^approve:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;const id=Number(ctx.match[1]);const x=q.topup.get(id);if(!x||x.status!=='pending')return ctx.answerCbQuery('Already processed');db.transaction(()=>{db.prepare("UPDATE topups SET status='approved',reviewed_at=?,reviewer_id=? WHERE id=? AND status='pending'").run(now(),String(ctx.from.id),id);db.prepare('UPDATE users SET balance=balance+?,updated_at=? WHERE id=?').run(x.amount,now(),x.user_id);})();await ctx.answerCbQuery('Confirmed');await ctx.editMessageText(`✅ <b>Payment confirmed</b>\n\nRequest #${id}\nAdded: ${money(x.amount)}\nUser: <code>${x.user_id}</code>`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('⬅️ Requests','a_topups')],[Markup.button.callback('⬅️ Admin','a_home')]])});bot.telegram.sendMessage(x.user_id,`✅ <b>Balance Added</b>\n\n${money(x.amount)} has been added after payment verification.\nCurrent balance: <b>${money(balance(x.user_id))}</b>`,{parse_mode:'HTML'}).catch(()=>{});});
bot.action(/^reject:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;const id=Number(ctx.match[1]);const x=q.topup.get(id);if(!x||x.status!=='pending')return ctx.answerCbQuery('Already processed');db.prepare("UPDATE topups SET status='rejected',reviewed_at=?,reviewer_id=? WHERE id=? AND status='pending'").run(now(),String(ctx.from.id),id);await ctx.answerCbQuery('Rejected');await ctx.editMessageText(`❌ <b>Payment rejected</b>\n\nRequest #${id}\nUser: <code>${x.user_id}</code>`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('⬅️ Requests','a_topups')],[Markup.button.callback('⬅️ Admin','a_home')]])});bot.telegram.sendMessage(x.user_id,`❌ <b>Payment Request Rejected</b>\n\nRequest #${id} was rejected. Please contact admin if you believe this is a mistake.`,{parse_mode:'HTML'}).catch(()=>{});});

async function adminUserSearch(ctx, input){const uid=input.replace(/\D/g,'');if(!uid)return ctx.reply('Send numeric Telegram ID.');const u=q.user.get(uid);ctx.session.adminStep=null;if(!u)return ctx.reply('User not found.');return showAdminUser(ctx,u);}
async function showAdminUser(ctx,u){await ctx.reply(`👤 <b>User</b>\n\nID: <code>${u.id}</code>\nName: ${esc(u.name)}\nUsername: ${u.username?'@'+esc(u.username):'—'}\nBalance: <b>${money(u.balance)}</b>\nStatus: <b>${u.banned?'BANNED':'ACTIVE'}</b>`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('➕ Add Balance',`a_u_add:${u.id}`),Markup.button.callback('➖ Minus Balance',`a_u_minus:${u.id}`)],[Markup.button.callback('💬 Message',`a_u_msg:${u.id}`)],[Markup.button.callback(u.banned?'🟢 Unban':'🔴 Ban',`a_u_ban:${u.id}`)],[Markup.button.callback('⬅️ Users','a_users')]])});}
bot.action('a_users',async ctx=>{if(!isAdmin(ctx.from.id))return;const users=q.users.all();await ctx.answerCbQuery();await ctx.editMessageText(`👥 <b>All Users</b>\n\nTotal: ${db.prepare('SELECT COUNT(*) n FROM users').get().n}\nSelect a user or search by ID:`,{parse_mode:'HTML',...Markup.inlineKeyboard(users.slice(0,50).map(u=>[Markup.button.callback(`${u.banned?'🔴':'🟢'} ${u.name} • ${u.id} • ${money(u.balance)}`,`a_user:${u.id}`)]).concat([[Markup.button.callback('🔎 Search User ID','a_user_search')],[Markup.button.callback('⬅️ Admin','a_home')]]))});});
bot.action(/^a_user:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;const u=q.user.get(ctx.match[1]);if(!u)return;await ctx.answerCbQuery();return showAdminUser(ctx,u);});
bot.action('a_user_search',async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session.adminStep='user_search';await ctx.answerCbQuery();await ctx.reply('🔎 Send the user Telegram ID:');});
function adminAdjustPrompt(ctx, uid, dir){ctx.session={...(ctx.session||{}),adminStep:dir>0?'user_add':'user_minus',targetUser:uid};return ctx.reply(`${dir>0?'➕':'➖'} Send amount to ${dir>0?'add':'remove'} from user <code>${uid}</code>:`,{parse_mode:'HTML'});}
bot.action(/^a_u_add:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;await ctx.answerCbQuery();return adminAdjustPrompt(ctx,ctx.match[1],1);});
bot.action(/^a_u_minus:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;await ctx.answerCbQuery();return adminAdjustPrompt(ctx,ctx.match[1],-1);});
async function adminAdjustBalance(ctx,t,dir){const amount=Number(t);const uid=ctx.session.targetUser;if(!Number.isFinite(amount)||amount<0)return ctx.reply('Send a valid amount.');db.prepare('UPDATE users SET balance=MAX(0,balance+?),updated_at=? WHERE id=?').run(dir*amount,now(),uid);ctx.session.adminStep=null;return ctx.reply(`✅ Balance updated.\nUser: ${uid}\nNew balance: ${money(balance(uid))}`);}
bot.action(/^a_u_msg:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session={adminStep:'user_message',targetUser:ctx.match[1]};await ctx.answerCbQuery();await ctx.reply('💬 Send the personal message:');});
bot.action(/^a_u_ban:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;const uid=ctx.match[1];db.prepare('UPDATE users SET banned=CASE WHEN banned=1 THEN 0 ELSE 1 END,updated_at=? WHERE id=?').run(now(),uid);await ctx.answerCbQuery('Updated');const u=q.user.get(uid);return showAdminUser(ctx,u);});

bot.action('a_admins',async ctx=>{if(!isAdmin(ctx.from.id))return;const as=db.prepare('SELECT * FROM admins ORDER BY role DESC,user_id').all();await ctx.answerCbQuery();await ctx.editMessageText(`👮 <b>Admins</b>\n\n${as.map(a=>`${a.role==='main'?'👑':'🛡️'} <code>${a.user_id}</code> — ${a.role==='main'?'MAIN':'ADMIN'}`).join('\n')}`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('➕ Add New Admin','a_admin_add')],[Markup.button.callback('➖ Remove Admin','a_admin_remove')],[Markup.button.callback('⬅️ Admin','a_home')]])});});
bot.action('a_admin_add',async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session.adminStep='new_admin';await ctx.answerCbQuery();await ctx.reply('👮 Send the Telegram numeric ID. This admin will get the same full management permissions.');});
bot.action('a_admin_remove',async ctx=>{if(!isAdmin(ctx.from.id))return;const as=db.prepare("SELECT * FROM admins WHERE role='admin'").all();await ctx.answerCbQuery();if(!as.length)return ctx.reply('No removable admin.');await ctx.reply('Select admin to remove:',Markup.inlineKeyboard(as.map(a=>[Markup.button.callback(`❌ ${a.user_id}`,`a_admin_del:${a.user_id}`)])));});
bot.action(/^a_admin_del:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;if(isMainAdmin(ctx.match[1]))return ctx.answerCbQuery('Main admin cannot be removed');db.prepare("DELETE FROM admins WHERE user_id=? AND role='admin'").run(ctx.match[1]);await ctx.answerCbQuery('Removed');await adminHome(ctx);});

bot.action('a_popup',async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session.adminStep='broadcast';await ctx.answerCbQuery();await ctx.reply('📢 Send the notification text. It will be sent to all non-banned users.');});

bot.action('a_coupons',async ctx=>{if(!isAdmin(ctx.from.id))return;const cs=q.activeCoupons.all();await ctx.answerCbQuery();await ctx.editMessageText(`🎟️ <b>Coupons</b>\n\n${cs.map(c=>`${c.code_label==='OWNER PRIVATE FREE'?'🔐':'🎟️'} <code>${esc(c.code_label)}</code> — ${c.type} — uses ${c.uses}/${c.max_uses<0?'∞':c.max_uses}`).join('\n')}`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('➕ Create Coupon','a_coupon_new')],[Markup.button.callback('🔐 Secret FREE Coupon','a_secret')],[Markup.button.callback('⬅️ Admin','a_home')]])});});
bot.action('a_coupon_new',async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session={adminStep:'coupon_code'};await ctx.answerCbQuery();await ctx.reply('🎟️ Send coupon code:');});

bot.action('a_secret',async ctx=>{if(!isAdmin(ctx.from.id))return;const c=q.couponByHash.get(SECRET);const p=c?.product_id?q.product.get(c.product_id):null;await ctx.answerCbQuery();await ctx.editMessageText(`🔐 <b>Private FREE Coupon</b>\n\nCode: <code>${esc(CONFIG.SECRET_COUPON_CODE)}</code>\nStatus: ${c?.active?'ACTIVE':'OFF'}\nSelected panel: <b>${esc(p?.name||'Not selected')}</b>\nUses: Unlimited\nValidity: Unlimited\nDiscount: 100% FREE\n\nThis code is not displayed in the user menu. Select one panel to bind it.`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('🎮 Select Panel','a_secret_panels')],[Markup.button.callback('🟢 Enable','a_secret_on'),Markup.button.callback('🔴 Disable','a_secret_off')],[Markup.button.callback('⬅️ Coupons','a_coupons')]])});});
bot.action('a_secret_panels',async ctx=>{if(!isAdmin(ctx.from.id))return;const ps=db.prepare('SELECT * FROM products WHERE active=1 ORDER BY id DESC').all();await ctx.answerCbQuery();await ctx.editMessageText('🎁 Select the ONE panel that BLACKFREECOD100 will make free:',{...Markup.inlineKeyboard(ps.map(p=>[Markup.button.callback(`${p.name} — ${money(p.price)}`,`a_secret_set:${p.id}`)]).concat([[Markup.button.callback('⬅️ Back','a_secret')]]))});});
bot.action(/^a_secret_set:(\d+)$/,async ctx=>{if(!isAdmin(ctx.from.id))return;const id=Number(ctx.match[1]);const c=q.couponByHash.get(SECRET);db.prepare('UPDATE coupons SET product_id=?,category_id=NULL,type=\'FREE\',value=0,max_uses=-1,expires_at=NULL,active=1 WHERE id=?').run(id,c.id);await ctx.answerCbQuery('Secret coupon set');await ctx.reply(`✅ BLACKFREECOD100 is bound to panel #${id}.\nOnly that selected panel can be taken free with this private code.`);});
bot.action('a_secret_on',async ctx=>{if(!isAdmin(ctx.from.id))return;db.prepare('UPDATE coupons SET active=1,max_uses=-1,expires_at=NULL WHERE code_hash=?').run(SECRET);await ctx.answerCbQuery('Enabled');await ctx.reply('🟢 Secret coupon enabled.');});
bot.action('a_secret_off',async ctx=>{if(!isAdmin(ctx.from.id))return;db.prepare('UPDATE coupons SET active=0 WHERE code_hash=?').run(SECRET);await ctx.answerCbQuery('Disabled');await ctx.reply('🔴 Secret coupon disabled.');});

bot.action('a_settings',async ctx=>{if(!isAdmin(ctx.from.id))return;await ctx.answerCbQuery();await ctx.editMessageText(`⚙️ <b>Settings</b>\n\n💗 bKash: <code>${esc(getSetting('payment_number'))}</code>\n🧾 Nagad: <code>${esc(getSetting('nagad_number'))}</code>\n🆘 Support: ${esc(getSetting('support'))}\n📢 Channel: ${esc(getSetting('channel'))}`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('💗 Change bKash','a_pay')],[Markup.button.callback('🆘 Change Support','a_sup')],[Markup.button.callback('📢 Change Channel','a_chan')],[Markup.button.callback('🖼️ bKash Logo URL','a_logo')],[Markup.button.callback('⬅️ Admin','a_home')]])});});
bot.action('a_pay',async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session={adminStep:'payment'};await ctx.answerCbQuery();await ctx.reply('Send new bKash number:');});
bot.action('a_sup',async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session={adminStep:'support'};await ctx.answerCbQuery();await ctx.reply('Send support username, e.g. @noxadmin:');});
bot.action('a_chan',async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session={adminStep:'channel'};await ctx.answerCbQuery();await ctx.reply('Send channel username, e.g. @noxmods:');});
bot.action('a_logo',async ctx=>{if(!isAdmin(ctx.from.id))return;ctx.session={adminStep:'bkash_logo'};await ctx.answerCbQuery();await ctx.reply('Send the direct bKash logo image URL:');});

bot.action('a_stats',async ctx=>{if(!isAdmin(ctx.from.id))return;await ctx.answerCbQuery();await ctx.editMessageText(`📊 <b>Statistics</b>\n\n👥 Users: ${db.prepare('SELECT COUNT(*) n FROM users').get().n}\n🎮 Active panels: ${db.prepare('SELECT COUNT(*) n FROM products WHERE active=1').get().n}\n🧾 Orders: ${db.prepare('SELECT COUNT(*) n FROM orders').get().n}\n💳 Pending payments: ${db.prepare("SELECT COUNT(*) n FROM topups WHERE status='pending'").get().n}\n👮 Admins: ${db.prepare('SELECT COUNT(*) n FROM admins').get().n}`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('⬅️ Admin','a_home')]])});});

bot.catch(err => console.error('NOX MODS ERROR:', err));
console.log(`Starting ${CONFIG.BOT_NAME}...`);
bot.launch().then(()=>console.log(`${CONFIG.BOT_NAME} is live.`)).catch(err=>{console.error(err);process.exit(1);});
process.once('SIGINT',()=>bot.stop('SIGINT'));
process.once('SIGTERM',()=>bot.stop('SIGTERM'));
